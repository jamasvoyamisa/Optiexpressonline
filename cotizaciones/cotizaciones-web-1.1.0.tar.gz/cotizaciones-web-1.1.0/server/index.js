const path = require('path');
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const routes = require('./routes');

const app = express();
const PORT = Number(process.env.PORT || 3080);
/** En producción detrás de nginx usa HOST=127.0.0.1 */
const HOST = process.env.HOST || '0.0.0.0';

app.set('trust proxy', 1);

const corsOrigin = process.env.CORS_ORIGIN;
app.use(cors({
  origin: corsOrigin ? corsOrigin.split(',').map((s) => s.trim()) : true,
  credentials: true,
}));

app.use(session({
  secret: process.env.SESSION_SECRET || 'cotizaciones-dev-cambiar-en-produccion',
  resave: false,
  saveUninitialized: false,
  name: 'cotizaciones.sid',
  cookie: {
    secure: String(process.env.SESSION_COOKIE_SECURE || '').toLowerCase() === 'true',
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  },
}));

app.use('/api', routes);

app.use(express.static(path.join(__dirname, '..', 'src', 'renderer')));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: err?.message || 'Error interno' });
});

app.listen(PORT, HOST, () => {
  const url = HOST === '0.0.0.0' ? `http://localhost:${PORT}` : `http://${HOST}:${PORT}`;
  console.log(`Cotizaciones (web) ${url} (bind ${HOST}:${PORT})`);
});
